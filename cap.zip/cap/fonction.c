#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "fonction.h"



void ajout (capteur c[])
{	int n,a,i;
	FILE  *f;
	f=fopen ("capteur.txt","a+");
	if (f!=NULL)
	{  printf ("combien de capteur vous voulez ajoutez \n");scanf("%d",a);
	   for (i=0;i<a;i++){
	   printf ("donner le nom puis le max puis min puis val aujourd'hui\n");
	   scanf("%s %d %d %d", c[i]->nom,&c[î]->vm,&c[î]->vn,&c[î]->va);
	   fprintf (f,"%s,%d,%d,%d\n", c[î]->nom,c[î]->vm,c[î]->vn,c[î]->va);}
		fclose(f);
	}
	if (f==NULL) 
	printf("impossible d'ouvrir le fichier");
	f=fopen("capteur.txt","r");
	if (f!=NULL)
	{
	  while(fscanf(f,"%s %d %d %d \n",c->nom,&c->vm,&c->vn,&c->va)!=EOF)
	  {n++;}
	  printf ("le nombre des capeur est %d",n);fclose(f);
}	}


void sup (capteur c[])
{char nom[20];
printf ("donner le nom du capteur que vous supprimer\n");scanf("%s",nom);
FILE *f ,*fcpy;
f= fopen ("db_capteur.txt","a+");
fcpy = fopen ("db_capteurcpy.txt","a+");
       while (fscanf (f,"%s,%d,%d,%d\n",c->nom,c->vm,c->va,c->vn)!=EOF)
       {if(strcmp(nom,c->nom)==0)
       {fprintf (fcpy,"%s,%d,%d,%d\n",c->nom,c->va,c->vm,c->vn);}}
       fclose(f);
       fclose(fcpy);
       remove("db_capteur.txt");
       rename("db_capteurcpy.txt","capteur.txt");
     
	   }
	   
void modifier (capteur c[])
{char nom[20];
printf ("donner le nom du capteur que vous modifier\n");scanf("%s",nom);
	FILE *f ,*fcpy;
f= fopen ("db_capteur.txt","a+");
fcpy = fopen ("db_capteurcpy.txt","a+");
       while (fscanf (f,"%s,%d,%d,%d\n",c->nom,c->vm,c->va,c->vn)!=EOF)
       {if(strcmp(nom,c->nom)==0)
       {fprintf (fcpy,"%s,%d,%d,%d\n",c->nom,c->va,c->vm,c->vn);}
	   else 
	   {fprintf(fcpy,"%s %d %d %d \n",c->nom,c->va,c->vm,c->vn);
	   }
	   
	   
	   }
       fclose(f);
       fclose(fcpy);
       remove("db_capteur.txt");
        rename("db_capteurcpy.txt","capteur.txt");
	
}


void recherche (capteur c[])
{char nom[20];
printf (" donner le nom du capteur que vous cherchez \n");scanf("%s",nom);
FILE *f ;

f= fopen ("db_capteur.txt","a+");

       while (fscanf (f,"%s %d %d %d\n",c->nom,c->vm,c->va,c->vn)!=EOF)
       {if(strcmp(nom,c->nom))
       {fprintf(f,"%s %d %d %d \n",c->nom,c->va,c->vm,c->vn);
	   }}
       fclose(f);
}
