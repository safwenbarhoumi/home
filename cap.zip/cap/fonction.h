#include<stdio.h>
#include<string.h>
#include<stdlib.h>


typedef struct
{char *nom[50];
int *vm;
int *vn;
int *va;
}capteur;

void ajout (capteur c[]);
void sup (capteur c[]);
void modifier (capteur c[]);
void recherche (capteur c[]);
