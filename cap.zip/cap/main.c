#include "fonction.c"
#include <stdio.h>
#include <string.h>


int main()
{

int choix,r;
capteur c[20];
	FILE *f;
f= fopen ("capteur.txt","a+");
printf("Donner le numero du fonction :\n ajouter(1),suprimer(2) modofier(3) ");
scanf("%d",&choix);

	if (choix==1)
	ajout(c);
	if (choix==2)
	sup(c);
	if (choix==3)
	modifier(c);
	if (choix==4)
	recherche(c);
			
		
}
