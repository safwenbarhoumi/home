#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include "temperature.h"


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window22;
window22=create_window2();
gtk_widget_show (window22);

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window4();
gtk_widget_show (window44);
}

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

FILE *f=NULL;
GtkWidget *nom,*prenom,*email,*cin,*nomu,*mot,*cmot,*window33;
char chnom[20];
char chprenom[20];
char chemail[20];
int icin;
char chnomu[20];
char chmot[20];
char chcmot[20];
nom = lookup_widget (button, "entry1");
prenom = lookup_widget (button, "entry2");
email = lookup_widget (button, "entry3");
cin = lookup_widget (button, "entry4");
nomu=lookup_widget (button, "entry5");
mot = lookup_widget (button, "entry6");
cmot = lookup_widget (button, "entry7");
strcpy(chnom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(chprenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(chemail, gtk_entry_get_text(GTK_ENTRY(email)));
icin=gtk_entry_get_text(GTK_ENTRY(cin));
strcpy(chnomu, gtk_entry_get_text(GTK_ENTRY(nomu)));
strcpy(chmot, gtk_entry_get_text(GTK_ENTRY(mot)));
strcpy(chcmot, gtk_entry_get_text(GTK_ENTRY(cmot)));
//ouvrir le fichier 
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{
//ecrire dans le fichier
fprintf (f,"%s \n %s \n %s \n %d \n %s \n %s\n \n\n\n",chnom,chprenom,chemail,icin,chnomu,chmot);
fclose(f);
}
else
printf ("\n Not found");

window33=create_window3();
gtk_widget_show (window33);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window4();
gtk_widget_show (window44);
}

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *username,*password,*window55;
char user[20];
char pasw[20];
int trouve;
username = lookup_widget (button, "entry8");
password = lookup_widget (button, "entry9");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(username)));
strcpy(pasw, gtk_entry_get_text(GTK_ENTRY(password)));
trouve=(verif(user,pasw));

if(trouve==1)
{
window55=create_window5();
gtk_widget_show (window55);
}

}



void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{	
}



void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *button6;
GtkWidget *treeview1;
button6=create_window7();
gtk_widget_show(button6);
treeview1=lookup_widget(button6,"treeview1");
afficher_temperature(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature(treeview);
	}
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window44;
window44=create_window8();
gtk_widget_show (window44);
}



void
on_button8_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *button6;
GtkWidget *treeview1;
GtkWidget *button8;
temperature p;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
GtkWidget *val;
jour=lookup_widget(objet_graphique,"jour");
heure=lookup_widget(objet_graphique,"heure");
num=lookup_widget(objet_graphique,"num");
val=lookup_widget(objet_graphique,"val");
p.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
p.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(heure));
p.num=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(num));
p.val=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));

button8=create_window7();
gtk_widget_show(button8);
treeview1=lookup_widget(button8,"treeview1");


	FILE *f;
	f=fopen("temperature.txt","a+");
	if (f!=NULL){

	fprintf(f,"%d %d %d %d \n",p.jour,p.heure,p.num,p.val);
	
	}
fclose(f);
afficher_temperature(treeview1);
}

void
on_treeview2_row_activated             (GtkTreeView     *treeview2,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_widget_show(button);
FILE* f;
FILE* f2;



gtk_widget_show(button);

GtkWidget *treeview1;


GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
char jour1[20],heure1[20],num1[20],a[10],b[10],c[10],d[10];
f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");
jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure1,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num1,gtk_entry_get_text(GTK_ENTRY(num)));


       




f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(jour1,a)!=0||strcmp(heure1,b)!=0||strcmp(num1,c)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
    remove("temperature.txt");
    rename("tmp.txt","temperature.txt");

button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");

afficher_temperature(treeview1);


}

void
on_suprime_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window11();
gtk_widget_show (window47);
}





void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window12();
gtk_widget_show (window47);
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window47;
window47=create_window13();
gtk_widget_show (window47);
}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget       *button0;
GtkWidget *treeview4;
FILE* f;
FILE* f2;

char a[10],b[10],c[10],d[10];
int x;

f=fopen("temperature.txt","r");
f2=fopen("sta.txt","a+");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {

             x==d;
                if ((x>53)==1||(x<51))
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);

       }
        
    fclose(f);
    fclose(f2);





button0=create_window15();
gtk_widget_show(button0);
treeview4=lookup_widget(button0,"treeview4");


	//fonction statistique


afficher_temperature3(treeview4);
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

gtk_widget_show(button);
FILE* f;
FILE* f2;
FILE* f3;
GtkWidget *treeview1;
GtkWidget *button00;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
char jour1[20],heure1[20],num1[20],a[10],b[10],c[10],d[10];
 remove("rech.txt");
jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");
strcpy(jour1,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure1,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num1,gtk_entry_get_text(GTK_ENTRY(num)));


       




f=fopen("temperature.txt","r");
f2=fopen("rech.txt","w");
f3=fopen("eur.txt","w");

  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
{
        if (strcmp(jour1,a)!=0||strcmp(heure1,b)!=0||strcmp(num1,c)!=0)
                
				
                   fprintf(f3,"%s %s %s %s\n",a,b,c,d);
else fprintf(f2,"%s %s %s %s\n",a,b,c,d);
       }
        
    fclose(f);
    fclose(f2);
    fclose(f3);

	//fonction rechercher


button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");

afficher_temperature4(treeview1);



}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)

{

GtkWidget *treeview1;

GtkWidget *jour;
GtkWidget *heure;
GtkWidget *num;
GtkWidget *val;
GtkWidget *jour1;
GtkWidget *heure1;
GtkWidget *num1;
GtkWidget *val1;

char jour2[20],heure2[20],num2[20],a[10],b[10],c[10],d[10],jour3[20],heure3[20],num3[20],val3[20];

jour=lookup_widget(button,"jour");
heure=lookup_widget(button,"heure");
num=lookup_widget(button,"num");

strcpy(jour2,gtk_entry_get_text(GTK_ENTRY(jour)));
strcpy(heure2,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(num2,gtk_entry_get_text(GTK_ENTRY(num)));



jour1=lookup_widget(button,"jour1");
heure1=lookup_widget(button,"heure1");
num1=lookup_widget(button,"num1");
val1=lookup_widget(button,"val1");
strcpy(jour3,gtk_entry_get_text(GTK_ENTRY(jour1)));
strcpy(heure3,gtk_entry_get_text(GTK_ENTRY(heure1)));
strcpy(num3,gtk_entry_get_text(GTK_ENTRY(num1)));
strcpy(val3,gtk_entry_get_text(GTK_ENTRY(val1)));




FILE* f=NULL;
FILE* f2;

f=fopen("temperature.txt","r");
f2=fopen("tmp.txt","w");


  
        while (fscanf(f,"%s %s %s %s",a,b,c,d)!=EOF)
        {
                if (strcmp(jour2,a)!=0||strcmp(heure2,b)!=0||strcmp(num2,c)!=0)
                
				
                   fprintf(f2,"%s %s %s %s\n",a,b,c,d);
                   else
                   fprintf(f2,"%s %s %s %s\n",jour3,heure3,num3,val3);}
        
    fclose(f);
    fclose(f2);
    remove("temperature.txt");
    rename("tmp.txt","temperature.txt");


button=create_window7();
gtk_widget_show(button);
treeview1=lookup_widget(button,"treeview1");


	//fonction modifier(jour,jour1)...

afficher_temperature(treeview1);

}


void
on_treeview3_row_activated             (GtkTreeView     *treeview3,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview3);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature3(treeview3);
	}
}

void
on_treeview4_row_activated             (GtkTreeView     *treeview4,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* jour;
	gchar* heure;
	gchar* num;
	gchar* val;
	temperature p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview4);

	if (gtk_tree_model_get_iter(model, &iter , path)){


	gtk_tree_model_get (GTK_LIST_STORE(model), &iter , 0 ,&jour,1 ,&heure, 2 ,&num, 3 ,&val ,-1);
	strcpy(p.jour,jour);
	strcpy(p.heure,heure);
	strcpy(p.num,num);
	strcpy(p.val,val);
	afficher_temperature3(treeview4);
	}
}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window2();
gtk_widget_show (window);
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window;
window=create_window5();
gtk_widget_show (window);
}

