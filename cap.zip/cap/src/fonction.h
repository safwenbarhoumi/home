int verif(char log[],char pw[]);
void type(int typ);
