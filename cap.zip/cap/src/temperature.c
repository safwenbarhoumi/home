#include<stdio.h>
#include "temperature.h"
#include<gtk/gtk.h>

enum
{
	EJOUR,
	EHEURE,
	ENUM,
	EVAL,
	COLUMNS
};

// L'ajout:
void ajouter_temperature(temperature p)
{ 
	FILE *f;
	f=fopen("temperature.txt","a+");
	if (f!=NULL){
while(fscanf(f,"%d %d %d %d \n",p.jour,p.heure,p.num,p.val)!=EOF){
	fprintf(f,"%d %d %d %d \n",p.jour,p.heure,p.num,p.val);}
	fclose(f);
	}}
//Supression:
void supprimer_temperature(temperature p)
{
	int jour;
	int heure;
	int num;
	int val;
	FILE *f,*g;
	f=fopen("temperature.txt","r");
	g=fopen("temp.txt","w");
	 if (f==NULL || g==NULL)
	{return;}
	else{
		while(fscanf(f,"%d %d %d %d \n",jour,heure,num)!=EOF)
	{
		 if (strcmp(p.jour,jour)!=0 || strcmp(p.heure,heure)!=0 ||strcmp(p.num,num)!=0  )
	fprintf (g,"%d %d %d %d \n",p.jour,p.heure,p.num,p.val);
	}
	fclose(f);
	fclose(g);
	remove("temperature.txt");
	rename("temp.txt","temperature.txt");
	}
}

////////////////////////////////////////////
void afficher_temperature(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char jour[50];
	char heure[50];
	char num[100];
	char val[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Jour",renderer,"text",EJOUR, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Heure",renderer,"text",EHEURE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" Numéro capteur",renderer,"text",ENUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 	Valeur capteur",renderer,"text",EVAL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("temperature.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("temperature.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",jour,heure,num,val)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EJOUR,jour,EHEURE,heure,EVAL,val,ENUM,num, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}
	
/////////////////////////////////////////////////////////
void afficher_temperature3(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char jour[50];
	char heure[50];
	char num[100];
	char val[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Jour",renderer,"text",EJOUR, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Heure",renderer,"text",EHEURE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" Numéro capteur",renderer,"text",ENUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 	Valeur capteur",renderer,"text",EVAL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("sta.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("sta.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",jour,heure,num,val)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EJOUR,jour,EHEURE,heure,EVAL,val,ENUM,num, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}
////////////////////////////////////////////////////////
void afficher_temperature4(GtkWidget *liste)
  {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char jour[50];
	char heure[50];
	char num[100];
	char val[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Jour",renderer,"text",EJOUR, NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Heure",renderer,"text",EHEURE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" Numéro capteur",renderer,"text",ENUM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 	Valeur capteur",renderer,"text",EVAL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("rech.txt", "r");
	if (f==NULL)
	{
	return;
	}
	else
	f=fopen("rech.txt","a+");
		while(fscanf(f,"%s %s %s %s \n",jour,heure,num,val)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter,EJOUR,jour,EHEURE,heure,EVAL,val,ENUM,num, -1);
		}
		fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	g_object_unref (store);
	}}
////////////////////////////////////////////////
	
void vider(GtkWidget *liste)
 {
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter ;
	GtkListStore *store;


	char jour[50];
	char heure[50];
	char num[100];
	char val[1000];
	store =NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Jour",renderer,"text",EJOUR, NULL);

	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" 		Heure",renderer,"text",EHEURE, NULL);

	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" Numéro capteur",renderer,"text",ENUM, NULL);

	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new ();
	column=gtk_tree_view_column_new_with_attributes(" Valeur capteur",renderer,"text",EVAL, NULL);}

	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	
	gtk_list_store_append (store, &iter);
	
		

	gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
	//g_object_unref (store);
	}



